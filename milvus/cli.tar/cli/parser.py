import sys

from .. import Milvus, IndexType, MetricType


def _create_table(_args):
    _dict = _args.__dict__
    _ip = _dict.get("host", None)
    if not _ip:
        print("Please input host address")
        sys.exit(1)
    print("Host {}".format(_ip))

    _port = _dict.get("port", None)
    if not _port:
        print("Please input port")
        sys.exit(1)
    print("Port {}".format(_port))

    _name = _dict.get("name", None)
    if not _name:
        print("Please input port")
        sys.exit(1)

    client = Milvus()
    status = client.connect(host=str(_ip), port=str(_port))
    if not status.OK():
        print(status.message)
        exit(1)

    print(status.message)

    param = {
        'table_name': _name,
        'dimension': 16,
        'index_file_size': 1024,
        'metric_type': MetricType.L2
    }

    status = client.create_table(param)
    print(status)

    client.disconnect()


def set_create_table_parser(_parsers):
    merge_parser = _parsers.add_parser("create_table", help="create table")

    merge_parser.set_defaults(function=_create_table)

    # group = merge_parser.add_mutually_exclusive_group()
    # group.add_argument("-o", "--out-file", help="indicate output yaml file")
    # group.add_argument("-i", "--input", action="store_true", help="indicate result store in origin file")

    merge_parser.add_argument("--host", help="indicate server address")
    merge_parser.add_argument("--port", help="indicate server port")
    merge_parser.add_argument("--name", help="indicate table name")
